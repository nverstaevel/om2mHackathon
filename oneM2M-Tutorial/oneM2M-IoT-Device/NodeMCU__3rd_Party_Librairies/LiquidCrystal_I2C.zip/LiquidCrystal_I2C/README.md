# LiquidCrystal_I2C

LiquidCrystal Arduino library for I2C LCD displays
